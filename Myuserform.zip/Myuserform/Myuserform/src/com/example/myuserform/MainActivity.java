package com.example.myuserform;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends Activity implements OnItemSelectedListener, OnClickListener {
	
	EditText idno;
	EditText name;
	Spinner course;
	RadioGroup rg;
	Button ok;
	Button cancel;
	
	String selectedCourse;
	String selectedSex;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
       idno = (EditText) this.findViewById(R.id.editText1);
       name = (EditText) this.findViewById(R.id.editText2);
       course = (Spinner) this.findViewById(R.id.spinner1);
       rg = (RadioGroup) this.findViewById(R.id.radioGroup1);
       ok = (Button) this.findViewById(R.id.button1);
       cancel = (Button) this.findViewById(R.id.button2);
       
       course.setOnItemSelectedListener(this);
       
       
    }




	@Override
	public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2,
			long arg3) {
		selectedCourse=course.getItemAtPosition(arg2).toString();
		ok.setOnClickListener(this);
		cancel.setOnClickListener(this);
		
	}


	@Override
	public void onNothingSelected(AdapterView<?> arg0) {
		// TODO Auto-generated method stub
		
	}




	@Override
	public void onClick(View arg0) {
		int btnId = arg0.getId();
		switch(btnId){
		case R.id.button1:
			String idnum = idno.getText().toString();
			String nm = name.getText().toString();
			
			int id = rg.getCheckedRadioButtonId();
			RadioButton btn = (RadioButton) this.findViewById(id);
			selectedSex = btn.getText().toString();
			
			String m = "IDNO : "+idnum + "\n" +"NAME : "+ nm + "\n" +"COURSE : "+ selectedCourse + "\n" +"SEX : "+ selectedSex;
			if((idnum.equals(""))&&(nm.equals(""))){
				Toast.makeText(this,"Fill all the fields", Toast.LENGTH_SHORT).show();
				
			}
			else{
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
				builder.setTitle("Output");
				builder.setMessage(m);
				builder.setNeutralButton("Okey",null);
				
			AlertDialog dialog = builder.create();
				dialog.show();
			}
				break;
		case R.id.button2:
			idno.setText("");
			name.setText("");
			course.setSelection(0);
			rg.setSelected(false);
			
			
			
			
				
			break;
			
		
		}
		
	}
    
}
